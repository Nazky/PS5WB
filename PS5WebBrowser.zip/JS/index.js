
function cleartxt(){
    document.getElementById("sc").value = "";
}

function search(){
    if(document.getElementById("sc").value.includes("http") || document.getElementById("sc").value.includes("https")) {
        document.getElementById("wb").src = document.getElementById("sc").value;
        document.getElementById('wb').contentWindow.location.reload(true);
    } else {
        alert("Please put a url (https://exemple.com) !")
    }
}

function geturl() {
    alert(document.getElementById('wb').contentWindow.location);
    document.getElementById("sc").value = document.getElementById('wb').src;
}

function gb() {
    document.getElementById("wb").contentWindow.history.go(-1);
}

function gf() {
    document.getElementById("wb").contentWindow.history.forward();
}

function fl(str) {
    document.getElementById("wb").src = str;
    document.getElementById('wb').contentWindow.location.reload(true);
}

function af() {
    if(document.getElementById("sc").value.includes("http") || document.getElementById("sc").value.includes("https")) {
        var targetDiv = document.getElementById('fav');
        targetDiv.innerHTML += '<a onclick=' + 'fl(document.getElementById("sc").value)' + ">" + document.getElementById("sc").value + "</a> <br/>";
    }

}